# Maintenance
  
Custom Maintenance - Minimal cleanup just for those maintenance tasks that you repeat regularly.  
  
Donations go a long way https://www.patreon.com/xCONFLiCTiONx
  
  
<a name="help"></a>
**HELP SECTION**
  
**Schedule Tasks:**  
  
You can set scheduled tasks to run whenever you like. The following is recommended:  
  
- /Logon  - Set Name to Maintenance - Logon **This just does a quick cleanup**
  
- /FullCheckup /PuranFD C: -s1 (REQUIRES Puran Defrag)  - Set Name to Maintenance - Monthly **This is Heavy maintenance**  
  
- You should not run heavy maintenance more than once a month, ideally. In most cases, you shouldn't ever have to run it but I personally run it every few months or if I feel I should run a check.
  
  
**GUI:**  

- Directories To Delete: Delete a directory and all the contents

- Files To Delete: Delete specific files

- Files To Hide: Hide specific files

- Path Files To Delete: Delete all files in a folder but not the folder itself

- Path Files To Delete Older: Delete all files in a folder but not the folder itself older than a set number of days - Proper use: 1, path (1 = 1 day, path = path to folder containing these files)

- Services To Disable: Disables the services

- Services To Manual: Sets the services to Manual (allows them to still be ran but only as required by the system/program)

- Tasks To Disable: Disables scheduled tasks
  
  
**TIPS:**  
  
- You can add text to the combo box and press enter and it will be added

- Disk Check is run once a month on next reboot from the first Monday's first boot up