# Maintenance
  
Custom Maintenance - Minimal optimizations for those maintenance tasks that you repeat regularly.  
  
Run directly for settings and some maintenance.

Run with argument: 'optimize' to run maintenance once which is hidden. (This is good to run at startup)

![Screenshot1](https://github.com/xCONFLiCTiONx/Maintenance/blob/master/Screenshot.jpg)  

Logs are in 'C:\ProgramData\EasyLogger\Maintenance\'